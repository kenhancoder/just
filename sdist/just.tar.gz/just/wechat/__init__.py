# -*- coding: utf-8 -*-
"""The wechat module."""
from . import views  # noqa
