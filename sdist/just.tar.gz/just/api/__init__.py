# -*- coding: utf-8 -*-
"""The api module."""
from . import views  # noqa
